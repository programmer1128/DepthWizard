#pragma once
#include <string>
#include <vector>
#include <cstdint>

class TiffExporter {
public:
    static bool writeFloatTiff(
        const std::string& outputPath,
        std::vector<float>& dsm_matrix,
        int width,
        int height,
        double* geoTransform,
        const char* projectionRef
    );

    static std::vector<uint8_t> exportTiffToBuffer(
        const std::string& uuid,
        std::vector<float>& dsm_matrix,
        int width,
        int height,
        double* geoTransform,
        const char* projectionRef
    );
};